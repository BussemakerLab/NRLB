## ------------------------------------------------------------------------
enh = NRLBtools::fly.enhancers()
names(enh)
enh$E3N

## ------------------------------------------------------------------------
models = NRLBtools::hox.models()
names(models)

## ------------------------------------------------------------------------
m = NRLBtools::hox.models()$ExdScr

## ------------------------------------------------------------------------
NRLBtools::logo(m$fits, m$index, m$mode, m$rc)

## ---- fig.show='asis'----------------------------------------------------
NRLBtools::nrlb.plot.score.genome(enh$E3N$seq, 
                                  m$fits, m$index, m$mode, m$rc,
                                  nPeaks = 10, annotate = TRUE)

## ------------------------------------------------------------------------
library(BSgenome.Dmelanogaster.UCSC.dm3)
gr = NRLBtools::fetch.as.track("http://bussemakerlab.org/NRLB/dm3/ExdScr", 
                    genome = BSgenome.Dmelanogaster.UCSC.dm3, 
                    chr.names = c("chrXHet", "chrYHet"),
                    model = m, normalize = "model")

## ------------------------------------------------------------------------
gr

## ------------------------------------------------------------------------
NRLBtools::optimal.site(m$fits, m$index, m$mode)

## ------------------------------------------------------------------------
range(score(gr))

## ------------------------------------------------------------------------
gr.new = gr
width(gr.new) = 1
gr.new

## ------------------------------------------------------------------------
gr.new = gr
end(gr.new[strand(gr.new)=="+"]) = start(gr.new[strand(gr.new)=="+"])
start(gr.new[strand(gr.new)=="-"]) = end(gr.new[strand(gr.new)=="-"])
gr.new

## ------------------------------------------------------------------------
end(gr[strand(gr)=="+"]) = start(gr[strand(gr)=="+"])
start(gr[strand(gr)=="-"]) = end(gr[strand(gr)=="-"])
bwfile.fwd = tempfile("ExdScr_fwd_", fileext=".bw")
export(gr[score(gr) > 1E-4 & strand(gr)=="+"], bwfile.fwd)
bwfile.rev = tempfile("ExdScr_rev_", fileext=".bw")
export(gr[score(gr) > 1E-4 & strand(gr)=="+"], bwfile.fwd)

## ------------------------------------------------------------------------
bw = import(bwfile.fwd)
bw
range(score(bw))

