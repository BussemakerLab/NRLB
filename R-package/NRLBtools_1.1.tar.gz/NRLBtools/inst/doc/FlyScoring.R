## ------------------------------------------------------------------------
enh = NRLBtools::fly.enhancers()
names(enh)
enh$E3N

## ------------------------------------------------------------------------
models = NRLBtools::hox.models()
names(models)

## ------------------------------------------------------------------------
m = models$ExdScr

## ------------------------------------------------------------------------
NRLBtools::logo(m$fits, m$index, m$mode)

## ---- fig.show='asis'----------------------------------------------------
model = models$ExdScr
NRLBtools::nrlb.plot.score.genome(enh$E3N$seq, 
                                  m$fits, m$index, m$mode, 
                                  nPeaks = 10, annotate = TRUE)

