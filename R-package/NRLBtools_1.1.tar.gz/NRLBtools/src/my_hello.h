char* my_hello(void);
char* my_string(char*);
char* my_arg_echo(int argc, char* argv[]);
