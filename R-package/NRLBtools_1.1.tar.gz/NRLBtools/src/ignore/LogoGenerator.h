int main_LogoGenerator(int argc, char *argv[]);
