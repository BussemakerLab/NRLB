int LogoGenerator_main(int argc, char **argv);

void LogoGenerator_C(char *output, 
                     char *file, 
                     char *logo, 
                     char *title, 
                     double ymin, 
                     double ymax);
